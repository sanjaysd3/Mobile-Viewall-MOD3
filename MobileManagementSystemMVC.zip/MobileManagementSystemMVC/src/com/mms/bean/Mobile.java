package com.mms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Mobiles")
@NamedQuery(name="getAllEmployees",query="select m from Mobile m")
public class Mobile {
	
	@Id
	@Column(name="Mob_id")
	private int mid;
	@Column(name="Mob_name")
	private String mname;
	@Column(name="Mob_price")
	private int mprice;
	@Column(name="Mob_desc")
	private String mdesc;
	
	public Mobile() {
		
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public int getMprice() {
		return mprice;
	}

	public void setMprice(int mprice) {
		this.mprice = mprice;
	}

	public String getMdesc() {
		return mdesc;
	}

	public void setMdesc(String mdesc) {
		this.mdesc = mdesc;
	}

	public Mobile(int mid, String mname, int mprice, String mdesc) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.mprice = mprice;
		this.mdesc = mdesc;
	}
	
	public Mobile(String mname, int mprice, String mdesc) {
		this.mname = mname;
		this.mprice = mprice;
		this.mdesc = mdesc;
	}
	
	
	

}
