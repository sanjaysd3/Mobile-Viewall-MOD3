package com.mms.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mms.bean.Mobile;
import com.mms.service.IMobileService;

@Controller
public class MobileController {
	
	@Autowired
	private IMobileService mserv;
	
	@RequestMapping("home")
	public String getHomePage()
	{
		return "home";
	}
	
	@RequestMapping("viewall")
	public ModelAndView viewall()
	{
		ModelAndView mv=new ModelAndView();
		ArrayList<Mobile> mlist=mserv.getAllEmpInfo();
		mv.setViewName("viewall");
		mv.addObject("data", mlist);
		return mv;
		
	}
	
	@RequestMapping("/book")
	public String doRecharge(Model m)
	{
		m.addAttribute("status","Mobile is Booked Successfully");
		return "book";
		
	}

}
