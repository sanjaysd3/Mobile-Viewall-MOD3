package com.mms.dao;

import java.util.ArrayList;

import com.mms.bean.Mobile;

public interface IMobileDao {

	ArrayList<Mobile> getAllEmpInfo();

}
