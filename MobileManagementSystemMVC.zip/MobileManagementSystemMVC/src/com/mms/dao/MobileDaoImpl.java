package com.mms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.mms.bean.Mobile;

@Repository
@Transactional
public class MobileDaoImpl implements IMobileDao{
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public ArrayList<Mobile> getAllEmpInfo() {
		
		Query qry=em.createNamedQuery("getAllEmployees");
		
		return (ArrayList<Mobile>) qry.getResultList();
	}

}
