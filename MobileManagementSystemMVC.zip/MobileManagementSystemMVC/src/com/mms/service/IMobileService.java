package com.mms.service;

import java.util.ArrayList;

import com.mms.bean.Mobile;

public interface IMobileService {

	ArrayList<Mobile> getAllEmpInfo();

}
