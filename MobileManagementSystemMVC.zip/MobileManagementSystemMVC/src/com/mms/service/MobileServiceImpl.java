package com.mms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.bean.Mobile;
import com.mms.dao.IMobileDao;

@Service
public class MobileServiceImpl implements IMobileService{
	
	@Autowired
	private IMobileDao mdao;

	@Override
	public ArrayList<Mobile> getAllEmpInfo() {
	
		return mdao.getAllEmpInfo();
	}

}
